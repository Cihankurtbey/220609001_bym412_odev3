import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import random


class SensorPublisher(Node):
    def __init__(self):
        super().__init__('sensor_publisher_node')
        # /sensor_value isimli topic'e Float32 veri yayınlayacağız
        self.publisher_ = self.create_publisher(Float32, '/sensor_value', 10)

        # 0.1 saniyede bir timer callback çalışacak
        timer_period = 0.1  # saniye
        self.timer = self.create_timer(timer_period, self.timer_callback)

        self.get_logger().info('sensor_publisher_node başlatıldı.')

    def timer_callback(self):
        # 0 ile 20 arasında rastgele bir sayı üret
        value = random.uniform(0.0, 20.0)

        msg = Float32()
        msg.data = float(value)

        # Mesajı yayınla
        self.publisher_.publish(msg)

        # Terminalde görüntülemek için log yaz
        self.get_logger().info(f'Yayınlanan sensör değeri: {msg.data:.2f}')


def main(args=None):
    rclpy.init(args=args)

    node = SensorPublisher()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # Node'u düzgün kapat
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

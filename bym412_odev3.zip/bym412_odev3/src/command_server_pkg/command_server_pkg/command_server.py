import rclpy
from rclpy.node import Node

from command_server_interfaces.srv import ComputeCommand



class CommandServer(Node):
    def __init__(self):
        super().__init__('command_server_node')

        self.srv = self.create_service(
            ComputeCommand,
            '/compute_command',
            self.handle_compute_command
        )

        self.get_logger().info(
            'command_server_node başlatıldı. /compute_command servisi hazır.'
        )

    def handle_compute_command(self, request, response):
        input_value = request.input

        if input_value > 10.0:
            response.output = "HIGH"
        else:
            response.output = "LOW"

        self.get_logger().info(
            f"Gelen input: {input_value:.2f} -> Cevap: {response.output}"
        )

        return response


def main(args=None):
    rclpy.init(args=args)
    node = CommandServer()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32


class DataProcessor(Node):
    def __init__(self):
        super().__init__('data_processor_node')

        # Subscriber: /sensor_value
        self.subscription = self.create_subscription(
            Float32,
            '/sensor_value',
            self.listener_callback,
            10
        )

        # Publisher: /processed_value
        self.publisher_ = self.create_publisher(Float32, '/processed_value', 10)

        self.get_logger().info("data_processor_node başlatıldı.")

    def listener_callback(self, msg):
        original_value = msg.data

        # ----- Örnek işlem: değer * 2 -----
        processed = float(original_value * 2.0)

        out_msg = Float32()
        out_msg.data = processed

        # Yayınla
        self.publisher_.publish(out_msg)

        self.get_logger().info(
            f"Alınan: {original_value:.2f} -> İşlenmiş: {processed:.2f}"
        )


def main(args=None):
    rclpy.init(args=args)
    node = DataProcessor()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

#!/bin/bash
set -e

# ROS 2 ortamını yükle
source /opt/ros/humble/setup.bash

# Workspace dizinine geç
cd /ws

# Build edilmiş workspace'i source et
source install/setup.bash

# Tüm node'ları launch dosyasıyla başlat
ros2 launch my_project my_project.launch.py

